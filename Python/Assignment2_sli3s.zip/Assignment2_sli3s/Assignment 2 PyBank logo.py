import turtle
t = turtle.Pen()
#program objective: create the PyBank logo
#create circle
t.color("green")
t.pensize(10)
t.circle(50)
#move turtle
t.up()
t.backward(24)
t.left(90)
t.forward(25)
t.down()
#create the P
t.color("red")
t.forward(20)
t.right(90)
t.circle(15,180)
t.left(90)
t.forward(40)
#move turtle
t.up()
t.left(90)
t.forward(29)
t.left(90)
t.forward(17)
t.right(135)
t.down()
#create the y
t.color("blue")
t.forward(21)
t.left(90)
t.forward(21)
t.backward(43)
