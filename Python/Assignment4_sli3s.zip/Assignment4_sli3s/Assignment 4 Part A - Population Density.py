#Programmer name: Susan Li
#Program creation date: August 7, 2022

#Population density of Maryland and Virginia

#Population and area of Maryland
state = "Maryland"
population = "6.062 million"
area = "12407 square miles"
print("State", " " * 4, "-" * 2, state)
print("Population", "-" * 2, population)
print("Area", " " * 5, "-" * 2, area)
#Population and area of Virginia
state = "Virginia"
population = "8.4 million"
area = "42775 square miles"
print("State", " " * 4, "-" * 2, state)
print("Population", "-" * 2, population)
print("Area", " " * 5, "-" * 2, area)
