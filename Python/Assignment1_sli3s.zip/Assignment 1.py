#Programmer's name: Susan
#Program creation date: July 25, 2022

#Program objective: introduce PyBank
print("Welcome to PyBank")
print("Your one stop online Banking App!")
print(" ")
print("------------------")
print("Account Number : 123-45-6789")
print("Account Balance: $125.50")
